#ifndef TARGA_HPP_
#define TARGA_HPP_

#include "palette.hpp"
#include "image.hpp"

image *load_targa(char *filename, palette *pal);

#endif
