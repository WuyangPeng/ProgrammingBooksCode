int joy_init(int argc, char **argv)
{ return 0; }

void joy_calibrate() { ; }

void joy_status(int &b1, int &b2, int &b3, int &xv, int &yv)
{ b1=b2=b3=xv=yv=0; }
