#ifndef _JDIR_HPP_
#define _JDIR_HPP_

void get_directory(char *path, char **&files, int &tfiles, char **&dirs, int &tdirs);


#endif
