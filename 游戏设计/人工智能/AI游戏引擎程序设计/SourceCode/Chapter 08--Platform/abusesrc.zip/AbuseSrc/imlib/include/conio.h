#include "system.h"
#ifdef __DOS
#include <conio.h>
#endif


