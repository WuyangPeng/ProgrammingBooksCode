#ifndef __INCLUDE_HPP_
#define __INCLUDE_HPP_
#include "image.hpp"
#include "palette.hpp"

void write_include(image *im, palette *pal, char *filename, char *name);

#endif

