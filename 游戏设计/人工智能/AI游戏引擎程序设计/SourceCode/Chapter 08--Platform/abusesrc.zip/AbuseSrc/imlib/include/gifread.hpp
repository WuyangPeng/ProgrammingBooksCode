#ifndef _GIF_READ_H_
#define _GIF_READ_H_
#include "image.hpp"
#include "palette.hpp"
image *read_gif(char *fn, palette *&pal);

#endif


