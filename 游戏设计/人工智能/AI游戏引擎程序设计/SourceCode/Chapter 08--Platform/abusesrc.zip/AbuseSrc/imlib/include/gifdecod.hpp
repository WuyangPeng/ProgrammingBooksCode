#ifndef __GIFDECOD__
#define __GIFDECOD__
#include "std.h"
#include "image.hpp"
#include <stdio.h>
WORD decode_gif_data(image *im, FILE *fp);
#endif

