#include "joy.hpp"

int joy_init(int argc, char **argv)
{  
}

void joy_status(int &b1, int &b2, int &b3, int &xv, int &yv)
{
}


void joy_calibrate()
{
}
