#ifndef DEFINES_H
#define DEFINES_H

#include <MacHeaders.h>
#define MANAGE_MEM
#define MEM_CHECK

#define H() printf("Reached %d.\n",__LINE__)

#endif