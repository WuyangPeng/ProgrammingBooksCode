/* STD.H - My own standard header file...
 */

#define LOCAL 
#define IMPORT //extern

#define FAST register
#include "system.h"

typedef short WORD;
typedef unsigned short UWORD;
typedef char TEXT;
typedef unsigned char UTINY;
#ifndef LONG
typedef long LONG;
#endif
typedef unsigned long ULONG;
typedef int INT;


