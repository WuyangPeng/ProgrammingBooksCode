#ifndef __MONOPRNT
#define __MONOPRNT
void mnclear();
void mnprintf(const char *format, ...);
#endif

