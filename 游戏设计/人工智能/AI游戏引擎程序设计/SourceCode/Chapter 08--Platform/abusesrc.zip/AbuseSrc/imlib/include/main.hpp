#ifndef __MAIN_HPP
#define __MAIN_HPP
#define main JCmain
#endif

