#ifndef __GLOBALS_HPP__
#define __GLOBALS_HPP__

extern unsigned xres, yres;

#ifdef __DOS
//#define DIRECT_SCREEN            // DOS only
#endif


#endif

