int MacMenu();
void MacKeyConfigMenu();
void MacPreferences();
