
class window_manager;
void do_key_config(window_manager *wm);
void load_image_into_screen(char *filename, char *name, int &x_loaded, int &y_loaded);
