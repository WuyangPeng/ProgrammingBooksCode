
class window_manager;
void do_monitor_config(window_manager *eh);
