#ifndef __SCENE_HPP_
#define __SCENE_HPP_

#define MAX_SCROLL_DATA 4096
#include "fonts.hpp"
void play_scene(char *script, char *filename, JCFont *font);

#endif
