char *lang_string(char *symbol);
