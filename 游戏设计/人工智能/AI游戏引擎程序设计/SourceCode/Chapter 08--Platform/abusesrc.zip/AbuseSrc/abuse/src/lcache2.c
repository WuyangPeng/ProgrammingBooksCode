#include "lisp.hpp"
#include "specs.hpp"

// stubs... (not called)
// andrew put your caching system here when you get it working.

long block_size(Cell *level)               // return number of bytes to save this block of code
{ return 0; }

void write_level(bFILE *fp, Cell *level)
{ ; }

Cell *load_block(bFILE *fp)
{ return NULL; }





