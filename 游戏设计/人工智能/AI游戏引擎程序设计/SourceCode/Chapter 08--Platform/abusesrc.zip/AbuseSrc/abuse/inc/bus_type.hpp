#ifndef BUS_TYPE_HPP
#define BUS_TYPE_HPP

#ifdef __sgi
#define WORD_ALLIGN 1
#endif

#ifdef sun
#define WORD_ALLIGN 1
#endif

#ifdef SUN3
#define WORD_ALLIGN 1
#endif

#ifdef SUN4
#define WORD_ALLIGN 1
#endif

#ifdef __sgi
#define WORD_ALLIGN 1
#endif

#ifdef _AIX
#define WORD_ALLIGN 1
#endif

#endif
