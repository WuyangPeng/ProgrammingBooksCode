#ifndef __chmorph_hpp_
#define __chmorph_hpp_

#include "morph.hpp"
#include "filter.hpp"

extern jmorph *normal_to_pacman;
extern color_filter *color_table;

void load_morphs();

#endif


