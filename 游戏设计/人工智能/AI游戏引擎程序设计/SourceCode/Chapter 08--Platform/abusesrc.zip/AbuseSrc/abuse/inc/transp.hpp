#ifndef __TRANSP_HPP_
#define __TRANSP_HPP_
#include "image.hpp"
#include "macs.hpp"
void transp_put(image *im, image *screen, uchar *table, int x, int y);

#endif
