#ifndef __NFCLIENT_HPP_
#define __NFCLIENT_HPP_

void connect_to_nfs_server(char *name, int port);

#endif
