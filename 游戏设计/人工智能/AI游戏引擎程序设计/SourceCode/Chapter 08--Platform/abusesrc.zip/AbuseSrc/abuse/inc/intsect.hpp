#ifndef __INTSECT_HPP_
#define __INTSECT_HPP_

int setback_intersect(long x1, long y1, long &x2, long &y2,
		      long xp1, long yp1, long xp2, long yp2, long inside);

#endif


