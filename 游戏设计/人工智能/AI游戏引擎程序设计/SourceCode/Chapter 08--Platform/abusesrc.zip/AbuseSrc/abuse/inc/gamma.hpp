#ifndef __GAMMA_HPP_
#define __GAMMA_HPP_

#include "palette.hpp"
void gamma_correct(palette *&pal, int force_menu=0);

#endif
