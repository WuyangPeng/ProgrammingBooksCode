#ifndef GRUE_MENU_HPP
#define GRUE_MENU_HPP
#include "fonts.hpp"

int menu(void *args, JCFont *font);             // reurns -1 on esc
void main_menu();

#endif
