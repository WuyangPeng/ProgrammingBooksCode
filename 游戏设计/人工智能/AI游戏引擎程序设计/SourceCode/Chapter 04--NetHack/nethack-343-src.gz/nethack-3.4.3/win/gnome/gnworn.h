/*	SCCS Id: @(#)gnbind.c	3.4	2002/04/15	*/
/* Copyright (C) 2002 by Dylan Alex Simon		*/
/* NetHack may be freely redistributed.  See license for details. */

#ifndef GnomeHackWornWindow_h
#define GnomeHackWornWindow_h

#include <gnome.h>
#include "config.h"
#include "global.h"

GtkWidget* ghack_init_worn_window();

#endif /* GnomeHackWornWindow_h */
