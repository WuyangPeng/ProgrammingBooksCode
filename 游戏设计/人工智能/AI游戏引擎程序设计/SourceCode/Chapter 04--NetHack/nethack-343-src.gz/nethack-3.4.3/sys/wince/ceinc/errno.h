/* empty file */

extern int errno;

