/*	SCCS Id: @(#)jtpdmain.h	3.0	2000/11/12	*/
/* Copyright (c) Jaakko Peltonen, 2000				  */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef _jtpdmain_h_
#define _jtpdmain_h_

#include "windows.h"
#include "jtp_dirx.h"

extern int WINAPI WinMain 
(
  HINSTANCE hThisInstance, 
  HINSTANCE hPrevInstance, 
  LPSTR lpszCmdParam, 
  int nCmdShow
);

#endif