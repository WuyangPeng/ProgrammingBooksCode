/*	SCCS Id: @(#)gnomeprv.h	3.3	2000/07/16	*/
/* Copyright (C) 1998 by Erik Andersen <andersee@debian.org> */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef GnomeHack_h
#define GnomeHack_h

/* These are the base nethack include files */
#include "hack.h"
#include "dlb.h"
#include "patchlevel.h"

#endif    /* GnomeHack_h */



