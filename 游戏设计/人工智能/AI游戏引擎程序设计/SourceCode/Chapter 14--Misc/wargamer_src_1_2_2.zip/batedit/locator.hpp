/*----------------------------------------------------------------------------*
 * Wargamer: Copyright (c) 1995-2001, Steven Green (wargamer@greenius.co.uk)  *
 * This Software is subject to the GNU General Public License.  			  *
 * For License information see the file COPYING in the project root directory *
 * For more information see the file README.								  *
 *----------------------------------------------------------------------------*/
#ifndef LOCATOR_HPP
#define LOCATOR_HPP

#ifndef __cplusplus
#error LOCATOR.hpp is for use with C++
#endif

/*
 *----------------------------------------------------------------------
 * $Id: locator.hpp,v 1.1 2001/06/13 08:52:36 greenius Exp $
 *----------------------------------------------------------------------
 * Copyright (C) 1996, Steven Morle-Green, All Rights Reserved
 * Parts of this code may have been written/modified by Paul Sample
 *----------------------------------------------------------------------
 *
 *	Tiny Map Window with controls
 *
 *----------------------------------------------------------------------
 */

#include "..\batwind\bw_tiny.hpp"     // Original from batwind

#if 0
#include "batdata.hpp"
#include "btwin_i.hpp"
#include "batmap_i.hpp"

namespace BattleWindows_Internal
{

class BW_LocatorImp;

class BW_Locator
{
	public:
		BW_Locator(RPBattleWindows batWind, RCPBattleData batData);
		~BW_Locator();

		void setZoomButtons(BattleMapInfo::Mode mode);
			// update the zoom buttons
		void setLocation(const BattleArea& area);
			// Set the location of the tiny map
		void update(bool all);
			// Redraw the tiny map

		void toggle();
			// Hide if showing, Show if hidden
		void show();
			// Display if showing
		void hide();
			// Hide
		bool isShowing() const;
			// return true if showing

	private:
		BW_LocatorImp* d_imp;
};

};	// namespace BattleWindows_Internal
#endif

#endif /* LOCATOR_HPP */

