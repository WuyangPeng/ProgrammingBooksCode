/*----------------------------------------------------------------------------*
 * Wargamer: Copyright (c) 1995-2001, Steven Green (wargamer@greenius.co.uk)  *
 * This Software is subject to the GNU General Public License.  			  *
 * For License information see the file COPYING in the project root directory *
 * For more information see the file README.								  *
 *----------------------------------------------------------------------------*/
#ifndef CAMPDATA_DLL_H
#define CAMPDATA_DLL_H
/*
 *----------------------------------------------------------------------
 * $Id: cdatadll.h,v 1.1 2001/06/13 08:52:37 greenius Exp $
 *----------------------------------------------------------------------
 * Copyright (C) 1996, Steven Morle-Green, All Rights Reserved
 * Parts of this code may have been written/modified by Paul Sample
 *----------------------------------------------------------------------
 *
 * Included by all files in CAMPDATA DLL
 *
 * Defines 
 *
 *
 *----------------------------------------------------------------------
 */


#if defined(NO_WG_DLL)
    #define CAMPDATA_DLL
#elif defined(EXPORT_CAMPDATA_DLL)
    #define CAMPDATA_DLL __declspec(dllexport)
#else
    #define CAMPDATA_DLL __declspec(dllimport)
#endif

#endif /* CAMPDATA_DLL_H */




