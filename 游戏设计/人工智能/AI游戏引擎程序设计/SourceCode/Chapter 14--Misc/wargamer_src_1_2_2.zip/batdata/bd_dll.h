/*----------------------------------------------------------------------------*
 * Wargamer: Copyright (c) 1995-2001, Steven Green (wargamer@greenius.co.uk)  *
 * This Software is subject to the GNU General Public License.  			  *
 * For License information see the file COPYING in the project root directory *
 * For more information see the file README.								  *
 *----------------------------------------------------------------------------*/
#ifndef BD_DLL_H
#define BD_DLL_H

/*
 *----------------------------------------------------------------------
 * $Id: bd_dll.h,v 1.1 2001/06/13 08:52:36 greenius Exp $
 *----------------------------------------------------------------------
 * Copyright (C) 1996, Steven Morle-Green, All Rights Reserved
 * Parts of this code may have been written/modified by Paul Sample
 *----------------------------------------------------------------------
 *
 *
 *
 *----------------------------------------------------------------------
 */

#if defined(NO_WG_DLL)
    #define BATDATA_DLL
#elif defined(EXPORT_BATDATA_DLL)
    #define BATDATA_DLL __declspec(dllexport)
#else
    #define BATDATA_DLL __declspec(dllimport)
#endif


#endif /* BD_DLL_H */

