/*
** Demonstrate use of CSyn Utilities.
** Test changing Sound assigned to a Voice.
**
** Author: Phil Burk
** Copyright 2001 SoftSynth.com, All Rights Reserved.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"
#include "csynutil.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define FILENAME_SAMPLE1   ("Trumpet.aiff")

/* Most CSyn functions return a negative number if an error occurs.
 * The error code can be converted to a string by CSyn_ErrorCodeToText().
 */
#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

CSynErr PlayScale( CSynContext context, CSynVoice voice,
				  int startNote, int numNotes, int duration );

int main(void)
{
	CSynErr     result;
	CSynMix     mix = NULL;
	CSynSound   sound1 = NULL;
	CSynSound   sound2 = NULL;
	CSynSound   sound3 = NULL;
	CSynVoice   voice1 = NULL;
	CSynContext context;
	AudioSample *audioSample;
	int         ticksPerBeat;

/* Create a context for the synthesis to occur. */
	context = CSyn_CreateContext();
	if( context == NULL ) goto error_return;

/* CSyn synthesis engine must be started before allocating unit generators. */
	result = CSyn_StartEngine( context, 0, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", error_return);
	
/* Create a mix for all the voices. */
	result = CSynMix_Create( context, &mix, 0 );
	TEST_ERROR(result, "CSynMix_Create", error_cleanup);

/* Load a sound template that we can use to make voices. */
	result = CSynSound_Load( mix, CIRCTYPE_AMPENV_SAMPLER, FILENAME_SAMPLE1, &sound1 );
	TEST_ERROR(result, "CSynSound_Load", error_cleanup);

/* Print some information about the sample. */
	audioSample = CSynSound_GetAudioSample( sound1 );
	if( audioSample == NULL )
	{
		result = -1;
		goto error_cleanup;
	}
	printf("audioSample base note = %d\n", audioSample->baseNote );

	result = CSynSound_Load( mix, CIRCTYPE_AMPENV_SAMPLER, FILENAME_SAMPLE1, &sound2 );
	TEST_ERROR(result, "CSynSound_Load", error_cleanup);

/* Modify the envelope of sound2. */
	{
		EnvelopeFrame frames[] = {
			{ 0.04, 1.0 }, // attack frame
			{ 0.04, 0.0 }  // release frame
		};
		CSynEnvelopeInfo     envInfo =
		{
			frames, sizeof(frames)/sizeof(EnvelopeFrame),
			-1, 0,  // no loops
			-1, 0,
			0
		};
		result = CSynSound_SetAmpEnvelope( sound2, &envInfo );
		TEST_ERROR(result, "CSynSound_SetAmpEnvelope", error_cleanup);
	}

	result = CSynSound_Load( mix, CIRCTYPE_BASIC_SAMPLER, FILENAME_SAMPLE1, &sound3 );
	TEST_ERROR(result, "CSynSound_Load", error_cleanup);

/* Create one voice with the same architecture as sound1 and sound2. */
	result = CSynVoice_Load( mix, CIRCTYPE_AMPENV_SAMPLER, NULL, &voice1 );
	TEST_ERROR(result, "CSynVoice_Load", error_cleanup);

	ticksPerBeat = ((int)CSyn_GetTickRate( context )) / 2; // 120 beats per minute

	printf("Play scale with default envelope.\n");
	CSynVoice_SetSound( voice1, sound1 );
	result = PlayScale( context, voice1, (60-12), 6, ticksPerBeat );
	TEST_ERROR(result, "PlayScale", error_cleanup);


	printf("Play scale with fast envelope.\n");
/* Change the sound that a voice uses. */
	CSynVoice_SetSound( voice1, sound2 );
	TEST_ERROR(result, "CSynVoice_SetSound", error_cleanup);
	result = PlayScale( context, voice1, (60-12), 6, ticksPerBeat );
	TEST_ERROR(result, "PlayScale", error_cleanup);

/* Foolishly try to use a sound with a different architecture. */
	if( CSynVoice_SetSound( voice1, sound3 ) >= 0 )
	{
		printf("ERROR - CSynVoice_SetSound should have caught mismatched architectures.\n");
	}

error_cleanup:
	if( voice1 ) CSynVoice_Delete( voice1 );  /* Just for testing, delete one voice. */
	if( mix ) CSynMix_Delete( mix );          /* Delete everything. */

/* Stop the engine when we are done. */
	CSyn_StopEngine( context  );
	CSyn_DeleteContext( context );

error_return:
	if( result < 0 ) PRINT(("Example failed = 0x%x = %s\n", result, CSyn_ErrorCodeToText( result ) ));
	return result;
}

/**************************************************************************/
CSynErr PlayScale( CSynContext context, CSynVoice voice,
				  int startNote, int numNotes, int duration )
{
	CSynErr     result;
	int         startTime, nextTime, offsetTime, releaseTime;
	CSynFixedPoint  frequency, amplitude;
	int         pitch;
	int         i;

/* Get the current time to use as a starting point for the song. */
	startTime = CSyn_GetTickCount( context );

/* Calculate an offset so that we can schedule events accurately in the future. */
	offsetTime = ((int)CSyn_GetTickRate( context )) / 4;
	nextTime = startTime + offsetTime;


/* Play an ascending series of notes. */
	pitch = startNote; /* Start an octave below middle C */
	for( i=0; i<numNotes; i++ )
	{
	/* Sleep and wake up before time of next note. */
		CSyn_SleepUntilTick( context, nextTime - offsetTime );

	/* Convert MIDI parameters to CSyn parameters. */
		frequency = CSynConvert_PitchToFrequency( ConvertIntegerToFixed( pitch ) );
		amplitude = CSynConvert_VelocityToAmplitude( ConvertIntegerToFixed( 64 ) );

	/* Schedule noteOn in immediate future. */
		result = CSynVoice_NoteOn( voice, nextTime,
						 frequency, amplitude );
		TEST_ERROR(result, "CSynVoice_NoteOn", error_cleanup);

	/* Schedule noteOff slightly later. */
		result = CSynVoice_NoteOff( voice, nextTime + (duration/2), &releaseTime );
		TEST_ERROR(result, "CSynVoice_NoteOn", error_cleanup);
		printf("relTime = %d\n", releaseTime );

	/* Advance time to start of next note. */
		nextTime += duration;
	 /* Raise pitch a major second. */
		pitch += 2;
	}

	/* Sleep and wake up after last note. */
	CSyn_SleepUntilTick( context, nextTime - offsetTime );

error_cleanup:
	return result;
}
