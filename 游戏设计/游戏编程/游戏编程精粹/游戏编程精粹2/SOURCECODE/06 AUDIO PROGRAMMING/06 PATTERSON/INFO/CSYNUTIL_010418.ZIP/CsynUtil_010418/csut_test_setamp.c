/*
** Demonstrate use of CSyn Utilities.
** Play a sequence with increasing amplitude.
** Then hold a note and decrease volume.
**
** Copyright 2001 (C) Phil Burk
** All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"
#include "csynutil.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define FILENAME_SAMPLE1   ("Trumpet.aiff")

/* Most CSyn functions return a negative number if an error occurs.
 * The error code can be converted to a string by CSyn_ErrorCodeToText().
 */
#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

int main(void)
{
	CSynErr     result;
	CSynMix     mix = NULL;
	CSynSound   sound1 = NULL;
	CSynVoice   voice1 = NULL;
	CSynVoice   voice2 = NULL;
	CSynContext context;
	int         startTime, nextTime, offsetTime, releaseTime;
	CSynFixedPoint  frequency, amplitude;
	int         pitch, velocity;
	int         i;
	int         ticksPerBeat;

/* Create a context for the synthesis to occur. */
	context = CSyn_CreateContext();
	if( context == NULL ) goto error_return;

/* CSyn synthesis engine must be started before allocating unit generators. */
	result = CSyn_StartEngine( context, 0, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", error_return);
	
/* Create a mix for all the voices. */
	result = CSynMix_Create( context, &mix, 0 );
	TEST_ERROR(result, "CSynMix_Create", error_cleanup);

/* Load a sound template that we can use to make voices. */
	result = CSynSound_Load( mix, CIRCTYPE_BASIC_SAMPLER, FILENAME_SAMPLE1, &sound1 );
	TEST_ERROR(result, "CSynSound_Load", error_cleanup);

/* Create two voices from the sound. */
	result = CSynVoice_Create( sound1, &voice1 );
	TEST_ERROR(result, "CSynVoice_Create", error_cleanup);
	result = CSynVoice_Create( sound1, &voice2 );
	TEST_ERROR(result, "CSynVoice_Create", error_cleanup);

/* Get the current time to use as a starting point for the song. */
	startTime = CSyn_GetTickCount( context );

/* Calculate an offset so that we can schedule events accurately in the future. */
	offsetTime = ((int)CSyn_GetTickRate( context )) / 4;
	nextTime = startTime + offsetTime;

	ticksPerBeat = ((int)CSyn_GetTickRate( context )) / 2; // 120 beats per minute

/* Play an ascending series of notes. */
	pitch = 40;
	velocity = 20;
	for( i=0; i<(25); i++ )
	{
	/* Sleep and wake up before time of next note. */
		CSyn_SleepUntilTick( context, nextTime - offsetTime );

	/* Convert MIDI parameters to CSyn parameters. */
		frequency = CSynConvert_PitchToFrequency( ConvertIntegerToFixed( pitch ) );
		amplitude = CSynConvert_VelocityToAmplitude( ConvertIntegerToFixed( velocity ) );
		printf("pitch = %d, velocity = %d\n", pitch, velocity );

	/* Schedule noteOn in immediate future. */
		result = CSynVoice_NoteOn( voice1, nextTime,
						 frequency, amplitude );
		TEST_ERROR(result, "CSynVoice_NoteOn", error_cleanup);

	/* Schedule noteOff slightly later. */
		result = CSynVoice_NoteOff( voice1, nextTime + (ticksPerBeat/2), &releaseTime );
		TEST_ERROR(result, "CSynVoice_NoteOff", error_cleanup);

	/* Advance time to start of next note. */
		nextTime += ticksPerBeat;
	 /* Raise pitch a minor second. */
		pitch += 1;
		velocity += 10;
		if( velocity > 127 ) velocity = 20;
	}

/* Play a steady note. */
	velocity = 127;
	pitch = 60;
	frequency = CSynConvert_PitchToFrequency( ConvertIntegerToFixed( pitch ) );
	amplitude = CSynConvert_VelocityToAmplitude( ConvertIntegerToFixed( velocity ) );
	printf("pitch = %d, velocity = %d\n", pitch, velocity );

	/* Schedule noteOn in immediate future. */
	nextTime += 100;
	result = CSynVoice_NoteOn( voice1, nextTime,
						 frequency, amplitude );
	TEST_ERROR(result, "CSynVoice_NoteOn", error_cleanup);
		
printf("Slowly ramp down volume on one note.\n");
	for( i=0; i<500; i++ )
	{
	/* Sleep and wake up before time of next note. */
		CSyn_SleepUntilTick( context, nextTime - offsetTime );

		amplitude = (int) (0.99 * amplitude);
		result = CSynVoice_SetAmplitude( voice1, nextTime, amplitude );
		TEST_ERROR(result, "CSynVoice_SetAmplitude", error_cleanup);
		nextTime += 5;
	}
	result = CSynVoice_NoteOff( voice1, nextTime, &releaseTime );
	TEST_ERROR(result, "CSynVoice_NoteOff", error_cleanup);

error_cleanup:
	if( voice1 ) CSynVoice_Delete( voice1 );  /* Just for testing, delete one voice. */
	if( mix ) CSynMix_Delete( mix );          /* Delete everything. */

/* Stop the engine when we are done. */
	CSyn_StopEngine( context  );
	CSyn_DeleteContext( context );

error_return:
	if( result < 0 ) PRINT(("Example failed = 0x%x = %s\n", result, CSyn_ErrorCodeToText( result ) ));
	return result;
}
