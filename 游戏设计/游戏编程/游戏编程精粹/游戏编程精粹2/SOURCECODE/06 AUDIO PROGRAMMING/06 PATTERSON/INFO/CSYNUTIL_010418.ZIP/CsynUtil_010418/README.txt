README for Demo Release of CSyn Utilities for Game Gems II
(C) 2001 Phil Burk, All Rights Reserved
Author: philburk@softsynth.com

NOTE: The CSynUtil library may only be used for evaluating
the functionality of the CSyn Utilities. It may not be incorporated
in a product, or redistributed by any means without a license
from SoftSynth.com. For information on obtaining the latest version
of the software, and for information on licensing, please visit:

   http://www.softsynth.com/csyn/

The CSyn Utilities support the loading of "sounds"
and the creation of "voices" that can play those sounds.
Basic noteOn() and noteOff() facilities are provided
to simplify the performance of music or sound effects.

This library is suitable for use in games or musical applications.
CSyn is a cross-platform library.
Macintosh and Windows are currently supported.
Linux and other platforms may be supported by the time you read this.

To compile a test program on Windows:

- link with CSynUtil.lib
- link with dsound.lib and winmm.lib

Test Programs:

csut_test_ampenv.c - experiment with various envelopes
csut_test_change   - test CSynVoice_SetSound()
csut_test_max.c    - measure how many voices can be played.
csut_test_setamp.c - test CSynVoice_SetAmplitude()
csut_test_setamp.c - test CSynVoice_SetAmplitude()
csut_test_setpan.c - test CSynVoice_SetPan()
csut_test_seq.c    - play a simple sequence of notes
