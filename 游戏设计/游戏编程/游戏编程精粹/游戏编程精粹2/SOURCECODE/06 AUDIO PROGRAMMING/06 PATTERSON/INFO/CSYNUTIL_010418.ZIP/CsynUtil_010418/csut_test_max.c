/*
** Demonstrate use of CSyn Utilities.
** Try to make as many voices as possible.
**
** Copyright 2001 (C) Phil Burk
** All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"
#include "csynutil.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define FILENAME_SOUND1   ("Trumpet.aiff")

#define MAX_VOICES      (200)
#define MAX_USAGE       (0.5)

/* Most CSyn functions return a negative number if an error occurs.
 * The error code can be converted to a string by CSyn_ErrorCodeToText().
 */
#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

CSynErr PlayScale( CSynContext context, CSynVoice voice,
				  int startNote, int numNotes, int duration );

int main(void)
{
	CSynErr     result;
	CSynMix     mix = NULL;
	CSynSound   sound1 = NULL;
	CSynVoice   voices[MAX_VOICES];
	CSynContext context;
	int         ticksPerSecond;
	CSynFixedPoint  frequency, amplitude;
	int         releaseTime;
	int         startTime;
	int         i,j;
	double      usage;
	int         numVoices;

/* Create a context for the synthesis to occur. */
	context = CSyn_CreateContext();
	if( context == NULL ) goto error_return;

/* CSyn synthesis engine must be started before allocating unit generators. */
	result = CSyn_StartEngine( context, 0, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", error_return);
	
/* Create a mix for all the voices. */
	result = CSynMix_Create( context, &mix, 0 );
	TEST_ERROR(result, "CSynMix_Create", error_cleanup);

/* Load a sound template that we can use to make voices. */
	result = CSynSound_Load( mix, CIRCTYPE_AMPENV_SAMPLER, FILENAME_SOUND1, &sound1 );
	TEST_ERROR(result, "CSynSound_Load", error_cleanup);

	for( i=0; i<MAX_VOICES; i++ )
	{
/* Create voice from the sound. */
		result = CSynVoice_Create( sound1, &voices[i] );
		TEST_ERROR(result, "CSynVoice_Create", error_cleanup);
		numVoices = i+1;
	
/* Get the current time to use as a starting point for the song. */
		startTime = CSyn_GetTickCount( context );
		ticksPerSecond = (int) CSyn_GetTickRate( context );

	/* Turn on all the voices so far. */
		for( j=0; j<(i+1); j++ )
		{

		/* Convert MIDI parameters to CSyn parameters. */
			frequency = CSynConvert_PitchToFrequency( ConvertIntegerToFixed( 40 + (j%24) ) );
			amplitude = CSynConvert_VelocityToAmplitude( ConvertIntegerToFixed( 64 ) ) / (i+1);

		/* Schedule noteOn in immediate future. */
			result = CSynVoice_NoteOn( voices[j], startTime,
							 frequency, amplitude );
			TEST_ERROR(result, "CSynVoice_NoteOn", error_cleanup);
		}

		CSyn_SleepForTicks( context, ticksPerSecond / 4 );

	/* If we exceed 80% of the CPU, bail out. */
		usage = CSyn_GetUsage( context );
		printf( "%d - Usage = %f\n", i, usage );

	/* Turn off all the voices so far. */
		startTime = CSyn_GetTickCount( context );
		for( j=0; j<(i+1); j++ )
		{
		/* Schedule noteOn in immediate future. */
			result = CSynVoice_NoteOff( voices[j], startTime, &releaseTime );
			TEST_ERROR(result, "CSynVoice_NoteOff", error_cleanup);
		}

		CSyn_SleepForTicks( context, ticksPerSecond / 4 );

		if( usage > MAX_USAGE ) break;
	}
	printf("%d voices created, usage = %g\n", numVoices, usage );

	do
	{
		CSyn_SleepForTicks( context, 50 );
		usage = CSyn_GetUsage( context );
		printf( "After AUTO_STOP, usage = %f\n", usage );
	} while( usage > (MAX_USAGE/8) );

error_cleanup:
	if( mix ) CSynMix_Delete( mix );          /* Delete everything. */

/* Stop the engine when we are done. */
	CSyn_StopEngine( context  );
	CSyn_DeleteContext( context );

error_return:
	if( result < 0 ) PRINT(("Example failed = 0x%x = %s\n", result, CSyn_ErrorCodeToText( result ) ));
	return result;
}
