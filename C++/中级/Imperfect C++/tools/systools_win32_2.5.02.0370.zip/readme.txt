Synesis Software System Tools - Win32
=====================================

Version:      2.5.02.0370
Release Date: 30th June 2004

These tools are provided free of charge, but with no
warranty whatsoever. You use them entirely at your
own risk.

The following are included in this release:

    clipboard.exe
    dskclear.exe
    exec.exe
    execc.exe
    exitwin.exe
    hardlink.exe
    intcopy.exe
    iwhereis.exe
    joinln.exe
    lnunique.exe
    nrngen.exe
    nvx.exe
    osver.exe
    osverw.exe
    pathchk.exe
    pausew.exe
    perlp.exe
    pfoped.exe
    ptime.exe
    pwd.exe
    rdempty.exe
    slsw.exe
    stdfilt.exe
    strbl.exe
    userid.exe
    whereis.exe
