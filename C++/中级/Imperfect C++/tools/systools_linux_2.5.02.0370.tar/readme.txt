Synesis Software System Tools - Linux 
=====================================

Version:      2.5.02.0370
Release Date: 30th June 2004

These tools are provided free of charge, but with no
warranty whatsoever. You use them entirely at your
own risk.

The following are included in this release:

    joinln.exe
    lnunique.exe
    nrngen.exe
    nvx.exe
    rdempty.exe
    slsw.exe
    strbl.exe
    whereis.exe

